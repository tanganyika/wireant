# wireant

A program for Linux, Windows, macOS and Android for modelling antennas: impedance, SWR, gain, front-to-back,
radiation patterns (2D and 3D), frequency sweeps and an optimizer. It is written in Rust with
egui, and the heavy calculations run on every processor core.

Despite the name, wireant isn't limited to wire antennas. Wires are the building block, but a
model can also include:

- **conducting plates**: reflectors, ground screens and car-body panels, with monopoles fed
  against them;
- **transmission lines**: feed lines, phasing lines and stubs;
- **baluns, ununs and coax chokes**, modelled as real windings with their losses;
- **matching networks**: L networks, gamma matches and coax sections, designed for you and
  added to the model;
- **ground systems**: buried radials, ground rods and counterpoises, a second ground such as
  the sea or a cliff edge, sloping ground for hillside sites, and the terrain around a site (hills, ridges, valleys);
- **arrays**: stacked and bayed copies of an antenna, fed in phase.

Around the model it also gives antenna reports, great-circle maps and RF exposure maps.

It was built as an independent take on the classic MMANA-GAL basic workflow. It is **not**
affiliated with or endorsed by the MMANA-GAL authors (JE3HHT, DL1PBD, DL2KQ), and contains none of
their code or files. MMANA-GAL basic is freeware for private use from <http://www.gal-ana.de/basicmm/>.

## Features

- **Three engines, plus your own NEC** (choose under Calculate → Engine; see [Engines compared](#engines-compared))
  - **wiremom** (default): built-in, multi-threaded, in-process
    ([wiremom](https://github.com/tanganyika/wiremom)). It uses MPIE with
    triangle currents and Galerkin testing, perfect or Sommerfeld real ground,
    wires in the ground, transmission lines and plates. Sweeps share Sommerfeld
    tables.
  - **MININEC-style** solver: the method MMANA uses. Real ground only affects the
    far field.
  - **NEC-2**: bundled public-domain `nec2c` with Sommerfeld-Norton real ground.
    Sweeps run many NEC-2 processes in parallel.
  - **External NEC** (experimental): your own licensed copy of NEC-4 or NEC-5, or
    another NEC program, as EZNEC does; see [Using your own NEC-4 or NEC-5](#using-your-own-nec-4-or-nec-5).
- **Files:** open and save MMANA `.maa`, NEC `.nec`
  (including 4nec2 `SY` symbols, helices, arcs, GM/GR/GX, `TL` lines and `SM`/`SC`
  plates), and EZNEC `.ez` (with its transmission lines, stubs, L networks,
  transformers and current sources).
- **Tabs:**
  - Geometry;
  - View:
    - click a wire to zoom in;
    - right-click a wire to edit it (length with the start, centre or end kept
      fixed, end points, radius, segments, insulation; joined wires follow);
    - scroll bars and right-drag move the view;
    - scale bar;
    - **Draw wires** mode:
      - *New wire*: drag to draw a wire; starting on a wire end joins it there.
        Release opens the wire editor so the exact length can be typed in.
      - *Adjust*: drag a wire end to change the length along the wire, or with
        Shift to move the end freely. Wire ends joined there follow. Drag a wire
        to move it.
      - Wires are drawn in the plane facing you (or a fixed XY, XZ or YZ
        plane) through the point the drag starts from, or through the origin.
        Ends snap to other wire ends and to a chosen grid.
      - A live readout shows the length and coordinates. Ctrl+drag rotates the
        view, and Undo (Ctrl+Z) reverses drawing changes;
  - Calculate: impedance, SWR, gain, F/B and the −3 dB beamwidths in the
    horizontal and vertical patterns;
  - Far field plots (movable gain marker);
  - 3D pattern (ARRL / dB / linear);
  - Frequency sweep;
  - Optimizer: changes wire lengths, positions or ends towards low SWR, jX near 0,
    high gain or high F/B. Wire ends joined to other wires or to the ground stay
    joined; click **Use optimized antenna** to keep the result.
- **Efficiency and power budget:** each calculation shows how much of the input
  power is radiated and how much is lost in the wires, loads, lines and the ground
  (Calculate tab, report and MCP), on every engine.
- **Modelling:** wire materials, voltage and current sources, lumped loads (R+jX, L/C/Q traps, series/parallel
  RLC), wire insulation (velocity factor), free / perfect / real ground, F/B rear
  range.
- **Transmission lines (wiremom and NEC-2 engines):** feed lines, phasing lines and
  stubs between any two places on wires. Each has an impedance, length, velocity
  factor, loss and reversal.
- **Transformers and chokes:** baluns and ununs (49:1, 9:1, 4:1…) as coupled
  windings with primary inductance, leakage, core loss and a compensating
  capacitor, fed in at the source with one click (wiremom and NEC-2 engines);
  air-wound coax chokes as a load on the coax shield, from turns and diameters.
- **Plates (wiremom engine):** flat conducting plates (reflectors, ground screens,
  car-body panels) meshed into triangles. A wire ending on a plate connects to it,
  so a monopole can be fed against a plate.
- **Ground systems (wiremom engine):** wires may run below z = 0 over real ground.
  Ground rods, buried radials and counterpoises are modelled in full, including
  the ground loss.
- **Second ground (all engines):** a different ground beyond a straight
  boundary at any bearing, or outside a circle, optionally lower (a cliff or
  bank), such as the sea next to a portable station or a salt marsh. As NEC-2's
  GD card, it changes the ground reflection in the patterns; the currents and
  impedance see the ground under the antenna. wiremom and MININEC can share each
  ray's reflection between the grounds over its first Fresnel zone, which matters
  when the shore is close. NEC-2 (and the "reflection point" option) uses the
  ground where each ray reflects. The View tab draws the boundary in blue. Ground
  presets fill in typical εr and σ.
- **Sloping ground (wiremom engine):** a hillside: the perfect or real ground
  tilted by a slope through the origin, falling toward any bearing. Wires keep
  their coordinates (masts stay vertical); radials lying on the slope and buried
  wires are measured against it. The patterns reach below the horizon downhill,
  where the takeoff angle drops by about the slope. The slope runs on for ever,
  so low-angle gain toward the valley is optimistic.
- **Terrain (wiremom engine):** the ground's height along one or more bearings
  around the site, as HFTA: each slope reflects on its own, ridges cut low rays
  as knife edges, and the patterns show a hilltop's lower takeoff angle or a
  valley's lost low angles. Profiles are typed in, imported from text files
  (metres or feet), or fetched all round the site from map elevation data
  (**From elevation data…**: give the antenna's latitude and longitude; the AWS
  Terrain Tiles, built from SRTM and national surveys, are downloaded once and
  cached; after that, ticking Terrain on any antenna fills it in for your site). They are blended between bearings and drawn in the View tab. Terrain
  shapes the patterns only; the impedance sees the ground under the antenna.
- **Tools menu:**
  - **Resonance finder:** sweeps a range on all cores (31 points by default),
    finds every reactance zero, and refines each with a few extra solves. The
    bandwidth edges are found by solving too, so they're accurate even when the
    band is narrower than the point spacing. Large models take a while: about
    one second per solve at 1,350 unknowns, so about a minute for a search. For each resonance it shows
    the type (series or parallel), R, SWR, the SWR bandwidth against the
    reference impedance, the bandwidth once matched to its own resistance, and Q
    (f·|dZ/df| / 2R). Plots of SWR and R/jX are included. "Use frequency" sets
    the working frequency; "Match…" opens the match calculator with that
    impedance.
  - **Match calculator:** for an impedance (typed in, from the last
    calculation, or from a resonance) and a target (default 50 Ω):
    - every L network (L and C, series or shunt first), with values, marked as
      low-pass or high-pass;
    - a gamma match: rod length and series capacitor, from element and rod
      diameters and spacing (the ARRL Antenna Book transmission-line model;
      approximate, so check by modelling the rod);
    - coax sections: a Regier series section of a chosen impedance (75, 93,
      35 Ω, …), or a length of feeder to a real-impedance point plus a
      quarter-wave transformer, as electrical degrees and metres at a velocity
      factor;
    - **Add to the antenna** puts the chosen solution into the model: L-network
      parts on a line from a small feed wire, the gamma rod, strap and
      capacitor as wires (with the rod length and capacitor tuned by the model
      itself), or the coax sections as lines.
  - **Antenna report (PDF):** an A4 report of the antenna (settings, a picture
    as on the View tab with its viewing direction, wire numbers and current
    colours, loads, lines, plates, comment), the Calculate tab's latest result
    with its efficiency and power budget, notes and results history, the horizontal and vertical patterns, and the
    resonance finder's and match calculator's current results with their plots.
    The save dialog suggests the antenna file's name with `.pdf` in its folder,
    or `untitled.pdf` in the last folder used. The PDF is written directly, with
    vector plots and standard PDF fonts, so nothing else needs installing.
    Once saved, the report opens in the default PDF viewer.
  - **Stack / bay array:** turns the antenna into an array of copies of itself,
    stacked one above another and/or bayed side by side, all fed in phase. The
    spacings start from the antenna's −3 dB beamwidth (DL6WU), and wires such as
    a mast or cross boom can be shared between the copies. **Undo** brings the
    single antenna back.
  - **Great circle map:** lays the horizontal pattern over an azimuthal
    equidistant world map centred on your Maidenhead locator, with the short and
    long paths. Set or drag the antenna's bearing, or click a place on the map to
    point the beam there; hover to read the locator, bearing, distance and gain.
  - **RF exposure:** maps the E and H fields around the antenna against ICNIRP
    1998, ICNIRP 2020 or FCC general-population reference levels, from the PEP,
    mode and time on air. It shows the limit as 3D surfaces around the antenna
    (with 30 % and 10 % surfaces) or as a coloured slice through a plane, with how
    far the limit reaches. The antenna report includes exposure maps too.
  - **Engine comparison report (PDF):** with an external NEC program set,
    calculates the antenna with wiremom and with that program and puts the two
    side by side: impedance, SWR, gain, F/B, efficiency, overlaid patterns and a
    21-point sweep.
- **Help** (Help menu, or F1 for the tab you are on): help pages built into the program.
  They are also in [docs/help](docs/help/README.md).
- **Preferences** (File → Preferences): whether to start with a blank antenna or the
  last one opened, whether to calculate antenna files as soon as they're opened,
  the engine used at start-up and the external
  NEC program. The last folder used for open/save is remembered too.
- **MCP server:** `wireant --mcp` lets AI assistants build, load, calculate,
  sweep and optimise antennas; see [Use from an AI assistant (MCP)](#use-from-an-ai-assistant-mcp).

## Use from an AI assistant (MCP)

`wireant --mcp` runs the program as a [Model Context Protocol](https://modelcontextprotocol.io)
server instead of opening a window. An MCP client such as Claude Code or Claude Desktop starts
it and talks to it over stdin/stdout (JSON-RPC, one message per line). The server keeps one
current antenna between calls.

Claude Code:

```bash
claude mcp add wireant -- /path/to/wireant --mcp
```

Other clients take the same command in their configuration, e.g. Claude Desktop's
`claude_desktop_config.json`:

```json
{ "mcpServers": { "wireant": { "command": "/path/to/wireant", "args": ["--mcp"] } } }
```

| Tool | What it does |
|---|---|
| `list_examples` | built-in example antennas and which engines are available |
| `new_antenna` | start from an example or an empty antenna |
| `open_file`, `save_file` | `.maa`, `.nec` and `.ez` files, as in the program |
| `get_antenna`, `set_antenna` | the whole antenna as JSON |
| `update_antenna` | change it with a JSON Merge Patch, e.g. `{"freq_mhz": 7.1, "ground": {"kind": "real"}}` |
| `set_wire`, `delete_wire` | change, add or remove one wire (sources and loads on a deleted wire go too) |
| `calculate` | impedance, SWR, gain and direction, F/B, efficiency and power budget (radiated, wires, loads, lines, ground); optional azimuth and elevation pattern cuts |
| `sweep` | R, X, SWR (and gain, F/B) over a frequency range |
| `optimize` | the optimizer: wire lengths, positions or ends against SWR, X, gain and F/B weights |
| `fetch_terrain` | fill the terrain with profiles all round from map elevation data, for a latitude and longitude (downloads, needs the network) |
| `report` | the PDF antenna report, as Tools → Antenna report: calculates, finds resonances and suggests matches itself; saved next to the antenna's file unless given a `path` |

`calculate`, `sweep`, `optimize` and `report` take an optional `engine` (`wiremom`, `mininec`, `nec2`,
or `external` once it is set up under Preferences),
and `calculate` and `report` an optional `freq_mhz`, for that call only. The server starts with the
Preferences start-up engine; `WIREANT_ENGINE` overrides it, as for the program. In the JSON, wires are numbered from 0; units are metres, MHz and ohms.

## Engines compared

| | **wiremom** (default) | **NEC-2** (nec2c) | **MININEC** |
|---|---|---|---|
| **How it calculates** | Mixed-potential method: current shapes overlap between neighbouring segments and are tested the same way | Classic NEC-2 method: point-tested, with a three-term current shape on each segment | Pulse currents, the original MININEC approach used in MMANA |
| **Real ground in impedance and currents** | Yes (Sommerfeld) | Yes (Sommerfeld–Norton) | No: perfect ground for the currents, real ground only in the pattern |
| **Wires in or through the ground** (radials, ground rods) | Yes | No | No |
| **Wires ending on real ground** | Treated as if the ground were perfect (warned) | Not reliable (warned) | Same as wiremom |
| **Transmission lines** | Yes, with loss | Yes, lossless only | No |
| **Transformers** (baluns, ununs) | Yes | Yes | No |
| **Plates** | Yes, flat plates | No (NEC-2 patches are only for closed surfaces) | No |
| **Steel wire** (permeability) | Yes | Approximated (σ/μr) | Yes |
| **Sloping ground** (hillside) | Yes, exact for an endless slope | No | No |
| **Terrain** (profiles around the site) | Yes, patterns only | No | No |
| **Second ground area** (sea, marsh, cliff) | Gradual change across the boundary, or the ground where each ray reflects | Only the ground where each ray reflects (GD card) | Gradual change or reflection point, like wiremom |
| **How it runs** | Inside the program, on all cores; sweeps reuse the slow ground calculation | A separate program run for each calculation, many at once | Inside the program, on all cores |

On the six built-in examples the three engines agree within 0.07 dB in gain. The
impedance spread is a few percent, except the Inverted V's reactance, where MININEC
differs from the other two.

In practice:

- **Free space or perfect ground:** all three agree closely.
- **Low antennas over real ground:** MININEC's impedance can be off. Its currents assume
  perfect ground, so a low dipole's feed resistance and resonance shift compared with
  wiremom and NEC-2.
- **Ground-mounted verticals, buried radials, ground rods:** only wiremom models these properly.
- **Feed lines, phasing lines and stubs:** wiremom includes line loss, NEC-2 treats lines
  as lossless, and MININEC can't model them.
- **Comparing with MMANA:** MININEC is closest to MMANA.
- **Comparing with EZNEC, 4nec2 or other NEC tools:** NEC-2 is the standard reference.

## Using your own NEC-4 or NEC-5

NEC-4 and NEC-5 are licensed from Lawrence Livermore National Laboratory and can't be
bundled, but if you have a copy the program can run it, as EZNEC Pro does. Under
**File → Preferences → External NEC program**:

- **Program:** the NEC executable.
- **Arguments:** how it takes its file names. `{in}` and `{out}` become `in.nec` and
  `out.txt`, e.g. `{in} {out}` or `-i{in} -o{out}`. For a program that asks for the
  names instead, leave this empty and tick **Type the file names when the program asks
  for them**.
- **Runs at once:** how many copies sweeps and the optimizer may start together
  (0 = one per processor thread); set 1 if the licence allows only one.

**Save and test** calculates the half-wave dipole with it. Then choose **External NEC**
under Calculate → Engine (or make it the start-up engine).

Each calculation writes the same NEC card deck as the NEC-2 engine (`GW`, `GN`, `LD`, `TL`,
`EX`, `FR`, `RP`, …) to `in.nec` in a temporary folder and runs the program there. The report
is read from `out.txt`, any other file the program writes, or what it prints, using the
NEC-2 report layout ("ANTENNA INPUT PARAMETERS", "RADIATION PATTERNS"). This is
**experimental**: it has been checked with stand-in programs, not with NEC-4 or NEC-5
themselves, whose input cards and report layout may differ. The last run's input,
output and messages are kept (Preferences shows where) so that a run that fails can be
looked at and the reader adjusted.

## Known limitations

These are the weaker spots, with how far they have been checked.

- **Wire-to-plate junctions (monopole fed against a plate):** nothing independent
  confirms the exact impedance.
  - The plate model converges smoothly as the mesh is refined: 39.9 Ω for a λ/4
    monopole on a 1 λ square plate, in line with published values for that size
    of ground plane.
  - Energy is conserved.
  - An equivalent wire-grid model differs by up to about 8%, approaching the
    plate result as the grid gets finer. (Wire grids themselves are known to be
    unreliable at a feed junction.)
- **Wires in the ground:** no other program available here can model them.
  nec2c can't: it gives a meaningless 259 − j232 Ω for a vertical connected to
  average ground. The engine is checked against exact limits, a classic
  ground-rod formula (Dwight, within 1.5%) and independent derivations of the
  wave along wires just above and below the surface (within about 1%) and of the
  field passing into the soil, not yet against measurements or NEC-4/5.
- **Wires lying on real ground** (height 0, such as radials laid on the soil) are
  modelled 1 cm under the surface, in the soil, with the ground's losses, or, if
  you choose (Ground: Wires at height 0), on top of the soil in the air, just
  touching it. A real radial is somewhere between: newly laid wire is nearer the
  second, wire that grass has grown round nearer the first. The two differ
  noticeably (26% against 29% efficiency, 48 against 39 Ω, for a 20 m vertical
  with 16 radials 5 m long over average ground), so the results give the
  impedance and efficiency for
  both. The reason is that a wire's loss and wave speed are set mostly by the
  few millimetres around it, and thin-wire engines (NEC included) can only put
  those millimetres wholly in air or wholly in soil, not partly in each. Even an
  exact calculation would hinge on details nobody measures: how far the wire has
  sunk in, the grass and leaf litter round it, how wet it is. The Ground help
  page ("Why a wire lying on the ground is hard to model") explains this in full.
- **Wires that only stop on the surface of real ground**, with nothing lying on
  it or below it (no rod or radials), use a perfect-ground stand-in for the
  currents. A point contact into lossy earth can't be modelled. The warning
  suggests adding a rod or radials.
- **Speed:**
  - **Buried wires:** a vertical with 8 buried radials takes about 70 ms per
    frequency (sea water needs finer tables: about 0.3 s for 16 radials).
  - **Everything else:** for the 3-element Yagi (24-point sweep with gain and
    F/B, 12 threads), wiremom takes about 110 ms in free space, against 90 ms for
    MININEC and 170 ms for NEC-2. On perfect ground all three take about
    130 ms. Over real ground wiremom takes 350 ms, NEC-2 210 ms, and MININEC
    130 ms (but MININEC doesn't put real ground into the currents). A single
    calculation is faster with wiremom than with NEC-2 in every case.
- **Plates:** flat parallelograms only, above the ground (not in it). Large
  plates grow the problem quickly; a 1 m plate at 144 MHz is fine, but meshes of
  thousands of triangles take seconds.
- **NEC-2 engine:** plates are refused. Line loss is ignored, and a velocity
  factor becomes the equivalent electrical length. With automatic segmentation,
  NEC-2 gets uniform segments, because it is inaccurate next to the very short
  segments of the MMANA-style taper.
- **Second ground:** pattern only, as in NEC-2: currents, impedance and ground
  loss near the antenna come from the main ground, so put the station's own
  ground (e.g. the salt marsh it stands on) there. The cliff face doesn't reflect
  or diffract. Circular boundaries smaller than the Fresnel zone are
  approximate. In NEC-2, a straight boundary at a bearing other than 0° is
  modelled by turning the antenna, which NEC-2 files can't express: exported
  decks keep the full description in a `CM wireant ground2` line, and NEC-2
  itself reads the GD card as a boundary along +X.
- **Sloping ground:** wiremom only, a single endless slope through the origin,
  and not together with a second ground.
- **Terrain:** wiremom only, patterns only (the impedance and efficiency see the
  ground under the antenna), two-dimensional toward each bearing, one ground
  for all of it, and not together with a second ground. Within a few degrees of
  grazing the results are approximate. Elevation data is the surface, partly
  including trees and buildings, on a grid about 30 m across (it smooths sharp
  peaks: Snowdon comes out about 40 m low). Importing a profile file isn't available
  on Android yet. NEC files keep it
  in the `CM wireant settings` line, but the deck itself describes level ground.
- **Files:** transmission lines in EZNEC files are skipped on import. `.maa` files
  can't hold transmission lines or plates, and saved `.ez` files can't hold those, the
  second ground, a sloping ground or terrain; saving says what was left out. Use `.nec` to keep everything.
- **Wire editor:** changes apply immediately. Press Calculate again for new
  results; the old results stay on screen until you do.

## Install on Windows or macOS

Download a package from the repository's Releases page (or the latest run on the Actions
tab: Build → Artifacts):

- **Windows 10 or 11:** `wireant-<version>-windows-x64-setup.exe` installs it (for you
  alone, no administrator rights needed, or for all users) with a Start menu entry, an
  optional desktop shortcut, `.maa`/`.nec`/`.ez` file types and an uninstaller in
  Settings → Apps. Or take `wireant-<version>-windows-x64-portable.zip`, unzip it anywhere
  and run `wireant.exe`. Neither is code-signed, so SmartScreen may warn the first time:
  choose **More info → Run anyway**.
- **macOS (Apple Silicon and Intel, macOS 11 or later):** `wireant-<version>-macos-universal.dmg`.
  Drag **wireant** to Applications. It isn't notarised, so open it the
  first time with right-click → **Open**, or allow it in System Settings → Privacy &
  Security. Open antenna files with File → Open (double-clicking them in Finder doesn't
  load them yet).

Or install and update it from a package manager:

- **Windows:** `winget install tanganyika.wireant` (once the winget catalogue has accepted it).
- **macOS:** `brew install --cask tanganyika/wireant/wireant` (the cask clears the quarantine
  flag, so it opens without the right-click step).

The NEC-2 engine is inside the program on all three systems. Settings are kept in
`%APPDATA%\wireant` on Windows and `~/Library/Application Support/wireant` on macOS.

To make the packages, push a version tag (`git tag v0.2.0 && git push --tags`): the Build
workflow then tests on all three systems and attaches the packages to a GitHub release.
Ordinary pushes test and package on Linux only, for quick results; to build the
Windows and macOS packages without a release, use Actions → Build → **Run workflow**.

## Install on Linux

Each release has two Linux packages (x86-64, glibc 2.31 or newer: Linux Mint 20 or later,
Ubuntu 20.04 or later, Debian 11 or later, Fedora, openSUSE ...):

- `wireant_<version>_amd64.deb` for Linux Mint, Ubuntu, Debian, Zorin, Pop!_OS: open it
  to install with the software installer, or `sudo apt install ./wireant_<version>_amd64.deb`.
  It installs `/usr/bin/wireant` with a menu entry, icon and file types; remove it with
  `sudo apt remove wireant`.
- `wireant-<version>-linux-x86_64.tar.gz` for any distribution, without root: unpack it and
  run `./install.sh` (installs to `~/.local`).

Or add the APT repository once, and new versions arrive with the system's other updates
(Linux Mint, Ubuntu, Debian, Zorin, Pop!_OS):

```sh
sudo install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://tanganyika.github.io/wireant/apt/wireant.gpg | sudo tee /etc/apt/keyrings/wireant.gpg >/dev/null
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/wireant.gpg] https://tanganyika.github.io/wireant/apt stable main" | sudo tee /etc/apt/sources.list.d/wireant.list
sudo apt update
sudo apt install wireant
```

If the window doesn't open, wireant tries plain OpenGL after the default renderer
(Vulkan/OpenGL ES), says why in a message box if neither works, and leaves the
message in `~/.cache/wireant/startup-error.txt` (`%LOCALAPPDATA%\wireant` on Windows).
`WIREANT_RENDERER=glow` starts it with OpenGL straight away. On Windows the default
renderer uses DirectX 12, as some older Vulkan drivers crash. If a graphics driver crashes
wireant while it starts, the next start uses OpenGL; `WIREANT_RENDERER=wgpu` tries the
default renderer again.

 To build it yourself you need Rust (<https://rustup.rs>) and a C
compiler (`sudo apt install build-essential` on Debian/Ubuntu/Zorin). Cargo fetches the
wiremom engine from <https://github.com/tanganyika/wiremom> at the commit pinned in
`Cargo.lock`. Then:

```sh
./install.sh        # builds if needed, installs to ~/.local (menu entry, icon, file types)
./uninstall.sh      # removes it again
```

Or just build and run:

```sh
cargo build --release
./target/release/wireant [antenna.maa|.nec|.ez]
```

Command-line options: `--tab <name>` opens a tab, and `--screenshot out.png` saves a picture of the
window and exits (used for automated checks).

## Install on Android

Each release has `wireant-<version>-android-arm64.apk` for 64-bit ARM phones and tablets
(Android 8 or later). Download it on the phone and open it; Android asks once to allow
installing apps from the browser or file manager you used. Later releases install over it.

The Android app is the same program with a touch layout: on a phone the tabs move to a bottom
bar, and light or dark follows the phone. File → Open and Save use Android's file picker. It
has the wiremom and MININEC engines only: there is no NEC-2 engine and no external NEC program,
because Android can't run them. To build the APK yourself, see [android/README.md](android/README.md).

## Project layout

| Path | What |
|---|---|
| `src/mom.rs` | built-in solver (segmentation, matrix fill, LU, far field, sweeps) |
| `src/nec.rs` | NEC-2 engine bridge (deck writer, report parser) |
| `src/wm.rs` | wiremom engine bridge (antenna → wiremom model, results → shared result types); the engine itself is the [wiremom](https://github.com/tanganyika/wiremom) crate |
| `nec2c/`, `build.rs` | bundled nec2c 1.3.1 source (public domain) and its build |
| `src/maa.rs`, `src/nec_file.rs`, `src/ez.rs` | file formats |
| `src/optimize.rs` | optimizer |
| `src/mcp.rs` | MCP server (`--mcp`) |
| `src/settings.rs` | settings file (Preferences) |
| `src/dem.rs` | terrain profiles from elevation data (tile download, cache, sampling) |
| `docs/help/`, `src/help.rs` | help pages (Markdown, built into the program) and the Help window |
| `src/app.rs`, `src/plots.rs` | user interface and plots |
| `MECHANICS.md`, `mechanics.json` | where each formula and value came from |
| `tools/cc.sh` | optional C compiler for nec2c (`NEC2C_CC=tools/cc.sh`; falls back to `zig cc` when no `cc` exists) |
| `.github/workflows/build.yml`, `packaging/` | CI and the Linux, Windows, macOS and Android packages |
| `android/` | Android app: builds the same sources into an APK ([android/README.md](android/README.md)) |

## Working on the wiremom engine at the same time

To build against a local wiremom checkout (`../wiremom`) instead of the pinned GitHub
commit, create `.cargo/config.toml` (git-ignored) containing:

```toml
[patch."https://github.com/tanganyika/wiremom"]
wiremom = { path = "../wiremom" }
```

While that is in place Cargo rewrites `Cargo.lock` without the pinned commit, so don't
commit `Cargo.lock` then. When the engine change is done: push wiremom, delete the file,
and run `cargo update -p wiremom` to pin the new commit.

`cargo test --release` runs the tests (solver accuracy, file round trips, NEC-2 agreement).

## Credits

- NEC-2: Lawrence Livermore National Laboratory (public domain); C translation `nec2c` by Neoklis Kyriazis (5B4AZ), bundled in `nec2c/` with its own README and COPYING.
- The wiremom engine: [wiremom](https://github.com/tanganyika/wiremom), licensed MIT OR Apache-2.0.
- The MININEC method: J. C. Logan and J. W. Rockway, Naval Ocean Systems Center.
- The EZNEC file layout follows the notes collected by the open-source `ezparse` project (S. Falco and H. McGavran); no code from it is used.

## License

Copyright (C) 2026 tanganyika

This program is free software: you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version. See [LICENSE](LICENSE).

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

The bundled `nec2c` source keeps its own terms (public domain, per its README), and the wiremom
engine is MIT OR Apache-2.0; both may be distributed as part of this GPL program.
